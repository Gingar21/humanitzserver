HumanitZ Server Manager - Version Windows

Lancement :
1. Double-clique sur server-manager.exe.
2. Le panel ouvre http://127.0.0.1:8765 dans le navigateur.

Fichiers inclus :
- server-manager.exe : application Windows prête à lancer.
- data : configuration, serveurs, compte panel.
- logs : logs du panel.
- mots_interdits.txt : mots surveillés pour la modération.

Important :
- Garde le dossier data à côté de server-manager.exe.
- Si tu remplaces l'exe par une nouvelle version, garde ton dossier data pour conserver ta configuration.
