@echo off
cd /d %~dp0
set PANEL_HOST=0.0.0.0
set PANEL_PORT=8765
server-manager.exe
